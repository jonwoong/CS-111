/* ISC license. */

/* MT-unsafe */

#include <skalibs/sgetopt.h>

subgetopt_t subgetopt_here = SUBGETOPT_ZERO ;
