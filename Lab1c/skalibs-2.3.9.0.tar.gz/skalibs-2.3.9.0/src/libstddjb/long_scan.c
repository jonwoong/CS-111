/* ISC license. */

#include <skalibs/ulong.h>
#include "fmtscan-internal.h"

SCANS(long, LONG)
