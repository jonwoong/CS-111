/* ISC license. */

#include <skalibs/uint32.h>
#include "fmtscan-internal.h"

SCANB(32)
