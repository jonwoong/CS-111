/* ISC license. */

#include <skalibs/tai.h>

tain_t const tain_zero = TAIN_ZERO ;
