/* ISC license. */

#include <skalibs/unixmessage.h>

unixmessage_sender_t const unixmessage_sender_zero = UNIXMESSAGE_SENDER_ZERO ;
