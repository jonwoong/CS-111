/* ISC license. */

/* MT-unsafe */

#include <skalibs/unixmessage.h>

unixmessage_sender_t unixmessage_sender_x_ = UNIXMESSAGE_SENDER_ZERO ;
