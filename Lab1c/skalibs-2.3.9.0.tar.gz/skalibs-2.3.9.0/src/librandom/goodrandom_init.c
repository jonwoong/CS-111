/* ISC license. */

/* MT-unsafe */

#include <skalibs/random.h>

int goodrandom_init (void)
{
  return 1 ;
}
