#!/bin/bash

chmod 777 testAll.sh
./testAll.sh


