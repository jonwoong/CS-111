#!/bin/bash

chmod 777 execlineScript1.sh execlineScript2.sh execlineScript3.sh
./execlineScript1.sh
./execlineScript2.sh
./execlineScript3.sh